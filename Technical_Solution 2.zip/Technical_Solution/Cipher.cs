﻿using System;
namespace Technical_Solution
{
    public abstract class Cipher
    {
        private string name;
        protected int cipherId;
        protected static int nextId = 0;
        public Cipher(string name)
        {
            this.name = name;
            cipherId = nextId;
            nextId++;
        }

        public string Name
        {
            get { return name; }
        }

        public int Id
        {
            get { return cipherId; }
        }

        public abstract int[] Encrypt(int[] plaintext);
        public abstract int[] Decrypt(int[] plaintext);
    }



    public abstract class Cipher<T> : Cipher
    {
        protected BreakMethod<T> breakMethod;
        protected SolKey<T> sk;

        public Cipher(string name) : base(name) { }

        public void SetBreakMethod(BreakMethod<T> breakMethod)
        {
            this.breakMethod = breakMethod;
        }

        public SolKey<T> Break()
        {
            return breakMethod.Break();
        }

        public abstract T GetKey();

        public override int[] Encrypt(int[] plaintext)
        {
            return Encrypt(plaintext, GetKey());
        }

        public override int[] Decrypt(int[] ciphertext)
        {
            return Decrypt(ciphertext, GetKey());
        }

        public abstract int[] Encrypt(int[] plaintext, T key);
        
        public abstract int[] Decrypt(int[] ciphertext, T key);

    }

    public abstract class CipherWithNullCharacter<T> : Cipher<T>
    {
        protected char nullCharacter = 'x';

        public CipherWithNullCharacter(string name) : base(name) { }

        public void SetNullCharacter(char nullCharacter)
        {
            this.nullCharacter = nullCharacter;
        }

        //Increases plaintext length until it is a multiple of 'x'
        protected int[] PadPlaintext(int[] plaintext, int x)
        {
            int lengthOfPaddedPlaintext = LengthOfPaddedPlaintext(plaintext, x);
            int[] paddedPlaintext = new int[lengthOfPaddedPlaintext];
            plaintext.CopyTo(paddedPlaintext, 0);

            for (int i = plaintext.Length; i < lengthOfPaddedPlaintext; i++)
            {
                paddedPlaintext[i] = Program.Integer(nullCharacter);
            }

            return paddedPlaintext;
        }

        protected int LengthOfPaddedPlaintext(int[] plaintext, int x)
        {
            int lengthOfPaddedPlaintext = plaintext.Length;
            if (plaintext.Length % x != 0)
            {
                lengthOfPaddedPlaintext += x - (plaintext.Length % x);
            }
            return lengthOfPaddedPlaintext;
        }

    }

    //SolKey is a structure with a solution and a key
    public struct SolKey<T>
    {
        public int[] solution;
        public T key;
    }


}