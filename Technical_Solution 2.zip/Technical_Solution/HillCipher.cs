﻿using System;
using System.Linq;
namespace Technical_Solution
{
    public class HillCipher : CipherWithNullCharacter<SquareMatrix>
    {
        private static HillCipher _instance = null;

        private HillCipher() : base("Hill cipher")
        {
        }

        public static HillCipher Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new HillCipher();
                }
                return _instance;
            }
        }

        public override SquareMatrix GetKey()
        {
            SquareMatrix matrix = new SquareMatrix(0);
            bool validKey = false, wordEntered = false;
            string word;
            int size;
            int[] wordArray;
            int[,] squareWordArray;
            do
            {
                do
                {
                    Console.WriteLine("Enter a word with a square number of letters:");
                    word = Console.ReadLine().ToLower();
                    if (word.All(char.IsLetter))
                    {
                        wordEntered = true;
                    }
                    else
                    {
                        Console.WriteLine("Please only use letters in the input.");
                    }
                } while (!wordEntered);

                if (Math.Sqrt(word.Length) % 1 == 0)
                {
                    size = (int)Math.Sqrt(word.Length);
                    wordArray = Program.ConvertStringToIntegerArray(word);
                    squareWordArray = Program.Convert1DArrayToSquareArray(wordArray, size);
                    matrix = new SquareMatrix(squareWordArray);

                    if (matrix.IsInvertible())
                    {
                        validKey = true;
                    }
                    else
                    {
                        Console.WriteLine("The matrix made by this key is not invertible. Please enter a different key.");
                    }

                }
                else
                {
                    Console.WriteLine("Word must have a positive square number (1, 4, 9...) number of letters.");
                }

            } while (!validKey);
            return matrix;
        }

        public override int[] Encrypt(int[] plaintext, SquareMatrix matrix)
        {
            int[] plaintextPadded = PadPlaintext(plaintext, matrix.Size);
            int[] ciphertext = new int[plaintextPadded.Length];
            int[] subarray = new int[matrix.Size];

            for (int i = 0; i < plaintextPadded.Length; i += matrix.Size)
            {
                Array.Copy(plaintextPadded, i, subarray, 0, matrix.Size);
                Array.Copy(matrix.ModMultitplyVector(subarray), 0, ciphertext, i, matrix.Size);
            }

            return ciphertext;
        }

        public override int[] Decrypt(int[] ciphertext, SquareMatrix matrix)
        {
            int[] plaintext = Encrypt(ciphertext, matrix.Inverse());
            return plaintext;
        }

    }

    public class HC_BruteForce : BruteForce<SquareMatrix>
    {
        private int blocksize;

        internal HC_BruteForce() : base(HillCipher.Instance) { }

        public void SetBlockSize(int blocksize)
        {
            this.blocksize = blocksize;
        }

        public override SolKey<SquareMatrix> Break()
        {
            if (blocksize == 0)
            {
                blocksize = GetBlocksize();
                Console.WriteLine($"A block-size of {blocksize} will be used. Brute-forcing now...");
            }

            SquareMatrix matrix;
            int[] array;
            int[,] squareArray;

            for (int i = 0; i < Math.Pow(26, blocksize * blocksize); i++)
            {
                array = Program.ConvertBaseN(i, 26, blocksize * blocksize);
                squareArray = Program.Convert1DArrayToSquareArray(array, blocksize);
                matrix = new SquareMatrix(squareArray);
                if (matrix.IsInvertible())
                {
                    TryKey(matrix);
                }
            }

            return ReturnSolKey();
        }


        private int GetBlocksize()
        {
            int[][] slices;
            int blocksize;
            double totalIoC, averageIoC;
            double[] averageIoCs = new double[20];

            for (int period = 1; period <= 20; period++)
            {
                totalIoC = 0;
                slices = Program.SlicePeriodically(ciphertext, period);
                for (int i = 0; i < period; i++)
                {
                    totalIoC += Program.IndexOfCoincidence(slices[i]);
                }
                averageIoC = totalIoC / period;
                averageIoCs[period - 1] = averageIoC;
            }

            for (int period = 1; period <= 20; period++)
            {
                Console.Write($"{period}:".PadLeft(3));
                Print_IoC_Bar(averageIoCs[period - 1]);
            }

            Console.WriteLine("Displayed above is a bar chart to represent the Index of Coincidence of slices taken from the ciphertext with different periods.");
            Console.WriteLine("Slices taken at multiples of the block-size will score higher than ones taken at other places.");
            Console.WriteLine("What do you believe to be the block-size?");

            blocksize = int.Parse(Console.ReadLine());

            return blocksize;

        }

        private void Print_IoC_Bar(double ioc)
        {
            int normIoC = Program.NormaliseIndexOfCoincidence(ioc);
            for (int i = 0; i < normIoC; i++)
            {
                Console.Write('-');
            }
            Console.WriteLine();
        }
    }

}
