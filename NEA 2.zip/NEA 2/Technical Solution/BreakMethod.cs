﻿using System;
namespace Technical_Solution
{
    public abstract class BreakMethod
    {
        static protected int[] ciphertext;
        static protected string ciphertextString;

        public static void SetCiphertext(int[] ciphertext)
        {
            BreakMethod.ciphertext = ciphertext;
            ciphertextString = Program.ConvertIntegerArrayToString(ciphertext);
        }

        public static void SetCiphertext(string ciphertextString)
        {
            BreakMethod.ciphertextString = ciphertextString;
            ciphertext = Program.ConvertStringToIntegerArray(ciphertextString);
        }
    }

    public abstract class BreakMethod<T> : BreakMethod
    {
        protected Cipher<T> cipher;

        public BreakMethod(Cipher<T> cipher)
        {
            this.cipher = cipher;
        }
        public abstract SolKey<T> Break();

    }
}