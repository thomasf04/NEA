﻿using System;
using System.Collections.Generic;
namespace Technical_Solution
{
    public class RailfenceCipher : Cipher<(int, int)>
    {
        private static RailfenceCipher _instance = null;

        private RailfenceCipher() : base("Rail fence cipher")
        {
        }

        public static RailfenceCipher Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new RailfenceCipher();
                }
                return _instance;
            }
        }

        public override (int, int) GetKey()
        {
            bool validKey = false, validOffset = false;
            int key = 0, offset = 0;
            do
            {
                Console.WriteLine("Enter the key:");
                validKey = int.TryParse(Console.ReadLine(), out key);
                if (!validKey)
                {
                    Console.WriteLine("Please enter a number.");
                }

            } while (!validKey);

            do
            {
                Console.WriteLine("Enter the offset:");
                validOffset = int.TryParse(Console.ReadLine(), out offset);
                if (!validOffset)
                {
                    Console.WriteLine("Please enter a number.");
                }

            } while (!validOffset);

            return (key, offset);
        }

        public override int[] Encrypt(int[] plaintext, (int, int) keyAndOffset)
        {
            int[] ciphertext = new int[plaintext.Length];
            int key = keyAndOffset.Item1;
            int offset = keyAndOffset.Item2;
            List<int>[] rows = new List<int>[key];
            int row = 0, counter = 0;
            bool increasing = true;

            for (int i = 0; i < offset; i++)
            {
                (row, increasing) = UpdateRowNumber(row, key, increasing);
            }

            for (int i = 0; i < key; i++)
            {
                rows[i] = new List<int>();
            }

            foreach (int i in plaintext)
            {
                rows[row].Add(i);
                (row, increasing) = UpdateRowNumber(row, key, increasing);
            }

            foreach (List<int> r in rows)
            {
                foreach (int i in r)
                {
                    ciphertext[counter] = i;
                    counter += 1;
                }
            }

            return ciphertext;
        }

        public override int[] Decrypt(int[] ciphertext, (int, int) keyAndOffset)
        {
            int[] plaintext = new int[ciphertext.Length];
            int[] numbers = new int[ciphertext.Length];
            int[] order = new int[ciphertext.Length];
            int key = keyAndOffset.Item1;
            int offset = keyAndOffset.Item2;

            for (int i = 0; i < ciphertext.Length; i++)
            {
                numbers[i] = i;
            }

            order = Encrypt(numbers, (key, offset));

            for (int i = 0; i < order.Length; i++)
            {
                plaintext[order[i]] = ciphertext[i];
            }

            return plaintext;
        }

        private (int, bool) UpdateRowNumber(int row, int key, bool increasing)
        {
            if (increasing)
            {
                row += 1;
                if (row == key)
                {
                    increasing = false;
                    row = key - 2;
                }
            }
            else
            {
                row -= 1;
                if (row == -1)
                {
                    increasing = true;
                    row = 1;
                }
            }
            return (row, increasing);
        }

    }

    public class RF_BruteForce : BruteForce<(int, int)>
    {
        public RF_BruteForce() : base(RailfenceCipher.Instance) { }
        public override SolKey<(int, int)> Break()
        {
            int maxKey = ciphertext.Length;
            int maxOffset;

            for (int key = 1; key < maxKey; key++)
            {
                maxOffset = 2 * key - 2;
                for (int offset = 0; offset < maxOffset; offset++)
                {
                    TryKey((key, offset));
                    if (Program.NormaliseTetragramFitness(bestFitness) == 100)
                    {
                        return ReturnSolKey();
                    }
                    
                }
            }

            return ReturnSolKey();
        }
    }



    //public class RF_BruteForce2 : BreakMethod<(int, int)>
    //{
    //    public RF_BruteForce2() : base(RailfenceCipher.Instance) { }
    //    public override SolKey<(int, int)> Break()
    //    {
    //        SolKey<(int, int)> sk;
    //        int[] solution, bestSolution = new int[ciphertext.Length];
    //        double fitness, bestFitness;
    //        (int, int) bestKeyOffet = (-1, -1);
    //        int maxKey = ciphertext.Length;
    //        int maxOffset;

    //        bestFitness = Program.TetragramFitness(ciphertext);

    //        for (int key = 1; key < maxKey; key++)
    //        {
    //            maxOffset = 2 * key - 2;
    //            for (int offset = 0; offset < maxOffset; offset++)
    //            {
    //                solution = cipher.Decrypt(ciphertext, (key, offset));
    //                fitness = Program.TetragramFitness(solution);
    //                if (fitness > bestFitness)
    //                {
    //                    if (Program.NormaliseTetragramFitness(fitness) == 100)
    //                    {
    //                        sk.solution = solution;
    //                        sk.key = (key, offset);
    //                        return sk;
    //                    }
    //                    bestSolution = solution;
    //                    bestFitness = fitness;
    //                    bestKeyOffet = (key, offset);
    //                }
    //            }
    //        }

    //        sk.solution = bestSolution;
    //        sk.key = bestKeyOffet;
    //        return sk;
    //    }
    //}
}
