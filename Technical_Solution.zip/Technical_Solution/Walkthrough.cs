﻿using System;
namespace Technical_Solution
{
    public class Walkthrough
    {
        private static Walkthrough _instance = null;
        private bool activated;

        private Walkthrough()
        {
        }

        public static Walkthrough Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Walkthrough();
                }
                return _instance;
            }
        }

        public void Activate()
        {
            activated = true;
        }

        public void TurnOff()
        {
            activated = false;
        }

        static private void Wait()
        {
            MyConsole.WriteLine('y', "(press any key to continue)");
            Console.ReadKey();
            Console.WriteLine();
        }

        static public void IdentifierMonogram(int[] ciphertext, double monogramFitness, bool high)
        {
            if (Walkthrough.Instance.activated)
            {
                double normMonogramFitness = Stats.NormaliseMonogramFitness(monogramFitness);
                MyConsole.WriteLine('y', $"The monogram fitness for this text is {monogramFitness}.");

                if (high)
                {
                    MyConsole.WriteLine('y', $"Normalised, this is {normMonogramFitness}/100. This is very high, and indicates that the text has not been encrypted with any sort of substitution cipher.");

                }
                else
                {
                    MyConsole.WriteLine('y', $"Normalised, this is {normMonogramFitness}/100. This is quite low, and indicates that the text has probably been encrypted with a substitution cipher.");
                }

                Wait();
                CompareMonogramFrequencies(ciphertext);

                if (high)
                {
                    MyConsole.WriteLine('y', "As you can see, they are very similar, hence a high monogram fitness.");
                }
                else
                {
                    MyConsole.WriteLine('y', "As you can see, there are noticeable differences, hence a low monogram fitness.");
                }

                Wait();

            }
        }

        static public void CompareMonogramFrequencies(int[] ciphertext)
        {
            double[] englishFreqsArray = { 8.55, 1.60, 3.16, 3.87, 12.10, 2.18, 2.09, 4.96, 7.33, 0.22, 0.81, 4.21, 2.53, 7.17, 7.47, 2.07, 0.10, 6.33, 6.73, 8.94, 2.68, 1.06, 1.83, 0.19, 1.72, 0.11 };
            double[] ciphertextFreqsArray = Stats.CreateFrequencyArray(ciphertext);

            for (int i = 0; i < 26; i++)
            {

                PrintMonogramBar(i, englishFreqsArray[i], ciphertextFreqsArray[i]);
            }

            MyConsole.WriteLine('y', "The relative frequencies of letters in English are represented by the blue bars.");
            MyConsole.WriteLine('y', "The relative frequencies of letters in the ciphertext are represented by the green bars.");
        }


        static private void PrintMonogramBar(int j, double englishFreq, double ciphertextFreq)
        {
            int englishDashes = (int)englishFreq * 5;
            int ciphertextDashes = (int)ciphertextFreq * 5;

            char letter = (char)(j + 'A');
            string letterString = letter.ToString();
            MyConsole.Write('y', $"{letterString} english:   ");
            for (int i = 0; i < englishDashes; i++)
            {
                MyConsole.Write('b', "-");
            }
            MyConsole.Write('y', $"\n{letterString} ciphertext:");
            for (int i = 0; i < ciphertextFreq; i++)
            {
                MyConsole.Write('g', "-");
            }

            Console.WriteLine();
        }


        static public void IdentifierEnglish(double tetragramFitness, bool english)
        {
            if (Walkthrough.Instance.activated)
            {
                double normTetragramFitness = Stats.NormaliseTetragramFitness(tetragramFitness);
                MyConsole.WriteLine('y', $"The tetragram fitness for this text is {tetragramFitness}.");

                if (english)
                {
                    MyConsole.WriteLine('y', $"Normalised, this is {normTetragramFitness}/100. This is very high, and suggests that the message has not been encrypted at all.");

                }
                else
                {
                    MyConsole.WriteLine('y', $"Normalised, this is {normTetragramFitness}/100. This is quite low, and indicates that the text has probably been encrypted with a transposition cipher.");
                    MyConsole.WriteLine('y', $"So far, we have narrowed the possible ciphers to Scytale cipher, Columnar transposition cipher, Permutation cipher, and Railfence cipher.");

                }

                Wait();

            }
        }

        static public void IdentifierIoC(double indexOfCoincidence, bool high)
        {
            if (Walkthrough.Instance.activated)
            {
                double normIoC = Stats.NormaliseIndexOfCoincidence(indexOfCoincidence);
                MyConsole.WriteLine('y', $"The index of coincidence for this text is {indexOfCoincidence}.");

                if (high)
                {
                    MyConsole.WriteLine('y', $"Normalised, this is {normIoC}/100. This is very high, and suggests that the message has been encrypted with a monoalphabetic substitution cipher.");
                    MyConsole.WriteLine('y', $"This has narrowed the possibilities down to Caesar cipher, Affine cipher, Keyword substitution cipher, or some other monoalphabetic substitution cipher.");

                }
                else
                {
                    MyConsole.WriteLine('y', $"Normalised, this is {normIoC}/100. This is quite low, and indicates that the text has been encrypted with a polyalphabetic substitution cipher.");
                    MyConsole.WriteLine('y', $"This has narrowed the possibilities down to either Vigenere or Hill cipher.");
                }

                Wait();

            }
        }

        static public void IdentifierAffine(double tetragramFitness, bool high)
        {
            if (Walkthrough.Instance.activated)
            {
                MyConsole.WriteLine('y', $"There are only 312 possible keys for affine ciphers.");
                MyConsole.WriteLine('y', $"In comparison, there are as many keys for the keyword substitution cipher as there are words in the English language. (A lot!)");
                MyConsole.WriteLine('y', $"For this reason, we will try all 312 decryptions using the affine cipher, and look at the tetragram fitness of the best one.");
                Wait();
                double normTetragramFitness = Stats.NormaliseTetragramFitness(tetragramFitness);
                MyConsole.WriteLine('y', $"The tetragram fitness for best candidate is {tetragramFitness}.");

                if (high)
                {
                    MyConsole.WriteLine('y', $"Normalised, this is {normTetragramFitness}/100. This is very high, and suggests that the message has been enrypted with an affine cipher OR a Caesar cipher.");
                    MyConsole.WriteLine('y', "(This is because the Caesar cipher is a special case of the affine cipher, where the multiplier is just 1.)");
                }
                else
                {
                    MyConsole.WriteLine('y', $"Normalised, this is {normTetragramFitness}/100. This is quite low, and indicates that the text has not been enrypted with either an affine cipher OR a Caesar cipher");
                    MyConsole.WriteLine('y', $"So far, we have narrowed the possible ciphers to Keyword substition cipher or some other monoalphabetic substitution cipher.");
                    MyConsole.WriteLine('y', $"The only thing we can do now is try every word in a big dictionary and hope that one of them works. This might take a couple of seconds...");
                }
                Wait();

            }
        }

        static public void IdentifierCaesar(bool equivalentToCaesar)
        {
            if (Walkthrough.Instance.activated)
            {
                if (equivalentToCaesar)
                {
                    MyConsole.WriteLine('y', $"If we look at the key associated with the best affine candidate, the multiplier 'a' is just 1.");
                    MyConsole.WriteLine('y', $"This means the the cipher used to encrypt this message is the Caesar Cipher!");
                }
                else
                {
                    MyConsole.WriteLine('y', $"If we look at the key associated with the best affine candidate, the multiplier is bigger than 1.");
                    MyConsole.WriteLine('y', $"This means the the cipher used to encrypt this message is the Affine Cipher!");
                }
            }
            Wait();

        }

        static public void IdentifierKeyword(double tetragramFitness, bool high)
        {
            if (Walkthrough.Instance.activated)
            { 
                double normTetragramFitness = Stats.NormaliseTetragramFitness(tetragramFitness);
                MyConsole.WriteLine('y', $"The tetragram fitness for best candidate is {tetragramFitness}.");

                if (high)
                {
                    MyConsole.WriteLine('y', $"Normalised, this is {normTetragramFitness}/100. This is very high, and means that our cipher has been encrypted using the Keyword Substitution Cipher!");
                }
                else
                {
                    MyConsole.WriteLine('y', $"Normalised, this is {normTetragramFitness}/100. This is quite low, and means that the message has been encrypted with some monoalphabetic substitution cipher that this program doesn't know about.");
                    MyConsole.WriteLine('y', "A statistical method will try and find the best decryption in a reasonable amount of time, and show you the best result it can find.");
                    MyConsole.WriteLine('y', "(We can't use brute force, because there are 26! possible keys, which is far too many to try. This is is roughly 400,000,000,000,000,000,000,000,000)");

                }
                Wait();
            }
        }


        static public void IdentifierPolyalphabetic()
        {
            if (Walkthrough.Instance.activated)
            {
                MyConsole.WriteLine('y',"The program will use a statistical approach called hill climbing to first see if the ciphertext can be broken using the Vigenere cipher");
                MyConsole.WriteLine('y', "(We can't use brute force, because the number of possible Vigenere keys grows exponentially. It would take too long to try them all)");
                Wait();
            }
        }

        static public void IdentifierHill()
        {
            if (Walkthrough.Instance.activated)
            {
                MyConsole.WriteLine('y', "Assuming the cipher used was Vigenere hasn't been very successful.");
                MyConsole.WriteLine('y', "This means we will assume the cipher used is the Hill Cipher!");
                Wait();
            }
        }

        static public void IdentifierVigenere()
        {
            if (Walkthrough.Instance.activated)
            {
                MyConsole.WriteLine('y', "Assuming the cipher used was Vigenere has been successful, and the statistical method has returned a likely candidate.");
                MyConsole.WriteLine('y', "This means we will assume the cipher used was the Vigenere Cipher!");
                Wait();
            }
        }

        static public void IdentifierTransposition()
        {
            if (Walkthrough.Instance.activated)
            {
                MyConsole.WriteLine('y',"There is no real way to tell apart tranposition ciphertexts. The only option is to brute force every one of them until we get an acceptable plaintext.");
                Wait();
            }
        }

        static public void EncryptCaesar(int[] plaintext, int shift)
        {
            if (Walkthrough.Instance.activated)
            {
                string letter = Utilities.UppercaseLetter(shift);
                MyConsole.WriteLine('y', $"Because key is '{letter}' or '{shift}', we need to shift our encryption alphabet {shift} place to the right");
                MyConsole.WriteLine('y', $"Press enter {shift} times to see this in action");

                int offset = Console.CursorTop;
                for (int i = 0; i <= shift; i++)
                {
                    Console.CursorTop = offset;
                    MyConsole.Write('b', "Plaintext alphabet:  ");
                    PrintAlphabet('b',0);

                    Print26Arrows();

                    MyConsole.Write('g', "Ciphertext alphabet: ");
                    PrintAlphabet('g',i);

                    MyConsole.WriteLine('y', $"Shifted {i}/{shift} times");
                    Wait();
                }


                MyConsole.WriteLine('y', $"Now we have our encryption 'alphabet', we are ready to encrypt the message.");
                //Show for first 20 (or less than 20 if lenggth < 20) characters
            }
        }

        static private void PrintAlphabet(char colourChar, int offset)
        {
            int index;
            for (int i = 0; i < 26; i++)
            {
                index = Utilities.mod(i + offset);
                MyConsole.Write(colourChar, $"{Utilities.UppercaseLetter(index)} ");
            }
            Console.WriteLine();
        }

        static private void Print26Arrows()
        {
            MyConsole.Write('y',"maps to...           ");
            for (int i = 0; i < 26; i++)
            {
                MyConsole.Write('y', "↓ ");
            }
            Console.WriteLine();
        }

    }
}
