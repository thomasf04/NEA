﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Technical_Solution
{
    public static class MyConsole
    {
        public static void Write(char colourChar, params string[] strings)
        {
            ConsoleColor initialColour = Console.ForegroundColor;
            switch (colourChar)
            {
                case 'b':
                    Console.ForegroundColor = ConsoleColor.Blue;
                    break;
                case 'g':
                    Console.ForegroundColor = ConsoleColor.Green;
                    break;
                case 'r':
                    Console.ForegroundColor = ConsoleColor.Red;
                    break;
                case 'm':
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    break;
                case 'y':
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    break;
                case 'c':
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;
            }
            foreach (string s in strings)
            {
                Console.Write(s);
            }
            Console.ForegroundColor = initialColour;
        }

        public static void WriteLine(char colourChar, params string[] strings)
        {
            Write(colourChar, strings);
            Console.WriteLine();
        }
    }
}