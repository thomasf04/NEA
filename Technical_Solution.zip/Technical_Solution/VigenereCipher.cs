﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Technical_Solution
{
    public class VigenereCipher : Cipher<string>
    {
        private static VigenereCipher _instance = null;

        private VigenereCipher()
        {
        }

        public static VigenereCipher Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new VigenereCipher();
                }
                return _instance;
            }
        }
        public override int[] Encrypt(int[] plaintext, string key)
        {
            int[] ciphertext = new int[plaintext.Length];
            for (int i = 0; i < plaintext.Length; i++)
            {
                ciphertext[i] = (plaintext[i] + Program.Integer(key[i % key.Length])) % 26;
            }
            return ciphertext;
        }

        public override int[] Decrypt(int[] ciphertext, string key)
        {
            int[] plaintext = new int[ciphertext.Length];
            for (int i = 0; i < ciphertext.Length; i++)
            {
                plaintext[i] = (ciphertext[i] + 26 - Program.Integer(key[i % key.Length])) % 26;
            }
            return plaintext;
        }

    }
    //----------------------------------------------------------------------------------------------------

    public abstract class VC_Breaker : BreakMethod<string>
    {
        protected bool keyLengthSet = false;
        protected int keyLength;

        internal VC_Breaker() : base(VigenereCipher.Instance) {}

        public void SetKeyLength(int keyLength)
        {
            this.keyLength = keyLength;
            keyLengthSet = true;
        }

        public void SetKeyLength_Kasiski(List<int[]> repeatedSequences)
        {
            int keyLength = 0;
            List<int>[] allOccurences = new List<int>[repeatedSequences.Count];
            int[] firstDifferences = new int[repeatedSequences.Count];
            List<int> occurences = new List<int>();

            for (int i = 0; i < repeatedSequences.Count; i++)
            {
                occurences = Program.BoyerMooreHorspool(ciphertext, repeatedSequences[i]);
                allOccurences[i] = occurences;
            }

            for (int i = 0; i < repeatedSequences.Count; i++)
            {
                if (allOccurences[i].Count >= 2)
                {
                    firstDifferences[i] = allOccurences[i][1] - allOccurences[i][0];
                }
                else
                {
                    firstDifferences[i] = 0;
                }
            }

            foreach (int difference in firstDifferences)
            {
                keyLength = Program.GreatestCommonDivisor(keyLength, difference);
            }

            this.keyLength = keyLength;
            keyLengthSet = true;
        }

        public void SetKeyLengh_IoC()
        {
            int[][] slices;
            double totalIoC, averageIoC;
            int period = 2;
            bool periodFound = false;

            while (period < 20 && !periodFound)
            {
                totalIoC = 0;
                slices = Program.SlicePeriodically(ciphertext, period);
                for (int i = 0; i < period; i++)
                {
                    totalIoC += Program.IndexOfCoincidence(slices[i]);
                }
                averageIoC = totalIoC / period;
                if (averageIoC > 1.7)
                {
                    keyLength = period;
                    keyLengthSet = true;
                    periodFound = true;
                }
                period++;
            }
            if (!periodFound)
            {
                throw new Exception("The message is not encrypted with a Vigenere cipher");
            }
        }
    }

    //Variational
    public class VC_BruteForce : VC_Breaker
    {
        public override SolKey<string> Break()
        {
            if (!keyLengthSet)
            {
                SetKeyLengh_IoC();
            }
            SolKey<string> sk;
            int[] plaintext = new int[ciphertext.Length];
            Random rnd = new Random();
            int[] keyArray = new int[keyLength];
            int[] newKeyArray = new int[keyLength];
            string newKey;
            int x;
            double fitness = -10;
            double newFitness;

            for (int i = 0; i < keyLength; i++)
            {
                keyArray[i] = 0;
            }

            while (fitness < -4.5655)
            {
                Array.Copy(keyArray, newKeyArray, keyLength);
                x = rnd.Next(keyLength);

                for (int i = 0; i < 26; i++)
                {
                    newKeyArray[x] = i;
                    newKey = Program.ConvertIntegerArrayToString(newKeyArray);
                    plaintext = cipher.Decrypt(ciphertext, newKey);
                    newFitness = Program.TetragramFitness(plaintext);

                    if (newFitness > fitness)
                    {
                        Array.Copy(newKeyArray, keyArray, keyLength);
                        fitness = newFitness;
                    }
                }

            }

            sk.key = Program.ConvertIntegerArrayToString(keyArray);
            sk.solution = cipher.Decrypt(ciphertext, sk.key);
            return sk;
        }
    }

    public abstract class VC_CribBreaker : VC_Breaker
    {
        protected string cribString;
        protected int[] crib;

        internal VC_CribBreaker(string cribString)
        {
            SetCrib(cribString);
        }

        internal VC_CribBreaker()
        {

        }

        public void SetCrib(string cribString)
        {
            this.cribString = cribString;
            this.crib = Program.ConvertStringToIntegerArray(cribString);
        }

    }

    //Subtracts at each position sequentially
    public class VC_Cribs1 : VC_CribBreaker
    {
        public override SolKey<string> Break()
        {
            SolKey<string> sk;

            if (cribString.Length < 4)
            {
                throw new ArgumentOutOfRangeException("crib.Length");
            }

            string ciphertextString = Program.ConvertIntegerArrayToString(ciphertext);
            int[] crib = Program.ConvertStringToIntegerArray(cribString);
            int n = 100;

            //WHAT IF CRIB IS ON BOUNDARY?
            string key = VigenereBreak_CribSearching(n);

            sk.key = key;
            sk.solution = cipher.Decrypt(ciphertext, key);
            return sk;
        }

        private string VigenereBreak_CribSearching(int n)
        {
            Console.CursorLeft = 0;
            Console.CursorTop = 0;
            Console.Clear();
            int[] slice, sliceDecrypted;
            int i = 0, offset = 0;

            bool exit = false;

            Console.WriteLine("Use the arrow keys to subtract the crib from different positions.");
            Console.WriteLine("Press enter when you would like to propose a key.");
            do
            {
                Console.CursorLeft = 0;
                Console.CursorTop = 2;
                Console.WriteLine(ciphertextString.Substring(offset, n));
                Console.Write(new string(' ', n));
                Console.CursorLeft = i;

                slice = new ArraySegment<int>(ciphertext, offset + i, crib.Length).ToArray();
                sliceDecrypted = cipher.Decrypt(slice, cribString);
                Console.Write(Program.ConvertIntegerArrayToString(sliceDecrypted));

                ConsoleKeyInfo choice = Console.ReadKey(true);
                if (choice.Key == ConsoleKey.RightArrow)
                {
                    if (i < n - crib.Length)
                    {
                        i++;
                    }
                    else
                    {
                        if (offset + i < ciphertext.Length - crib.Length)
                        {
                            offset += 1;
                        }
                    }

                }
                if (choice.Key == ConsoleKey.LeftArrow)
                {
                    if (i > 0)
                    {
                        if (offset > 0)
                        {
                            offset -= 1;
                        }
                        else
                        {
                            i--;
                        }
                    }
                }
                if (choice.Key == ConsoleKey.Enter)
                {
                    exit = true;

                }

            } while (!exit);

            Console.WriteLine("\nWhat do you think the key is?");
            string key = Console.ReadLine();
            return key;

        }
    }


    //Subtracts at each position and orders by tetragram fitness
    public class VC_Cribs2 : VC_CribBreaker
    {
        public override SolKey<string> Break()
        {
            if (cribString.Length < 4)
            {
                throw new ArgumentOutOfRangeException("crib.Length");
            }

            SolKey<string> sk;
            int[] slice, sliceDecrypted;
            string sliceString, key;
            double normalisedFitness;
            Dictionary<int[], double> dictionary = new Dictionary<int[], double>();
            List<KeyValuePair<int[], double>> orderedList;


            for (int i = 0; i <= ciphertext.Length - crib.Length; i++)
            {
                slice = new ArraySegment<int>(ciphertext, i, crib.Length).ToArray();
                sliceDecrypted = cipher.Decrypt(slice, cribString);
                dictionary.Add(sliceDecrypted, Program.TetragramFitness(sliceDecrypted));
            }

            orderedList = dictionary.OrderByDescending(x => x.Value).ToList();

            Console.WriteLine("Here are the top 20 possible keys:");
            Console.WriteLine("NOTE: It is possible that only part of the key is uncovered and the key may be shifted to the left of right.");
            for (int i = 0; i < 20; i++)
            {
                sliceString = Program.ConvertIntegerArrayToString(orderedList[i].Key);
                normalisedFitness = Program.NormaliseTetragramFitness(orderedList[i].Value);
                Console.WriteLine($"{i + 1}: {sliceString} ({normalisedFitness})");
            }

            Console.WriteLine("\nWhat do you believe to be the key?");
            key = Console.ReadLine();
            sk.key = key;
            sk.solution = cipher.Decrypt(ciphertext, key);

            return sk;
        }
    }
}