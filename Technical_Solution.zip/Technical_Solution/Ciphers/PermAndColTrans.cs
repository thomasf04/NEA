﻿using System;
using System.Linq;
namespace Technical_Solution
{
    public abstract class PermAndColTransCipher : CipherWithNullCharacter<int[]>
    {
        public PermAndColTransCipher(string name, bool hasCribBreakMethods) : base(name, hasCribBreakMethods) { }


        public override string KeyToString(int[] key)
        {
            return Utilities.ConvertIntegerArrayToString(key);
        }

        public override int[] GetKey()
        {
            string key = "";
            bool validKey = false;
            MyConsole.WriteLine('c', "Enter the key (a word):");
            do
            {
                key = Console.ReadLine().ToLower();
                if (key.All(char.IsLetter) && key.Length > 0)
                {
                    validKey = true;
                }
                else if (key.Length == 0)
                {
                    MyConsole.WriteLine('r', "Please type in the key below.");
                }
                else
                {
                    MyConsole.WriteLine('r', "Please only use letters in the input.");
                }
            } while (!validKey);
            return Utilities.ConvertWordToPermutation(key);
        }

        public int[] Encrypt(int[] plaintext, string key)
        {
            return Encrypt(plaintext, Utilities.ConvertWordToPermutation(key));
        }

        public abstract int EncryptionIndex(int paddedPlaintextLength, int[] permutation, int p, int i);

        public override int[] Encrypt(int[] plaintext, int[] permutation)
        {
            int pLength = permutation.Length;
            int[] paddedPlaintext = PadPlaintext(plaintext, pLength);
            int[] ciphertext = new int[paddedPlaintext.Length];
            for (int p = 0; p < pLength; p++)
            {
                for (int i = 0; i < paddedPlaintext.Length / pLength; i++)
                {
                    ciphertext[EncryptionIndex(paddedPlaintext.Length, permutation, p, i)] = paddedPlaintext[i * pLength + p];
                }
            }
            return ciphertext;
        }

        public int[] Decrypt(int[] ciphertext, string key)
        {
            return Decrypt(ciphertext, Utilities.ConvertWordToPermutation(key));
        }

        public abstract int DecryptionIndex(int ciphertextLength, int[] permutation, int p, int i);

        public override int[] Decrypt(int[] ciphertext, int[] permutation)
        {
            int pLength = permutation.Length;
            int[] plaintext = new int[ciphertext.Length];

            for (int p = 0; p < pLength; p++)
            {
                for (int i = 0; i < ciphertext.Length / pLength; i++)
                {
                    plaintext[i * pLength + p] = ciphertext[DecryptionIndex(ciphertext.Length, permutation, p, i)];
                }
            }
            return plaintext;
        }

    }




    //The permutation cipher and columnar transposition cipher use identical brute force methods, differing only by the cipher used to decrypt the message
    public abstract class PermAndColTran_BruteForce : BruteForce<int[]>
    {
        public PermAndColTran_BruteForce(Cipher<int[]> cipher) : base(cipher) { }

        public override SolKey<int[]> Break()
        {
            int[][] permutations;
            int maxKeyLength = 9;

            for (int keyLength = 1; keyLength <= maxKeyLength; keyLength++)
            {
                permutations = Utilities.HeapsAlgorithm(keyLength);
                foreach (int[] perm in permutations)
                {
                    TryKey(perm);
                    if (Stats.NormaliseTetragramFitness(bestFitness) == 100)
                    {
                        return ReturnSolKey();
                    }
                }
            }

            return ReturnSolKey();
        }
    }

}