﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Technical_Solution
{
    //Mode 1 adds letters alphabetically after last letter of keyword e.g. keywordabcfg...
    //Mode 2 adds letters alphabetically starting with last letter of key word e.g. keywordefghi...
    public enum KeywordSubstitutionModes
    {
        One,
        Two
    }

    public class KeywordSubstitutionCipher : Cipher<(string, KeywordSubstitutionModes)>
    {
        private static KeywordSubstitutionCipher _instance = null;
        private KeywordSubstitutionModes mode;

        private KeywordSubstitutionCipher() : base("Keyword substitution cipher", false)
        {
        }

        public static KeywordSubstitutionCipher Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new KeywordSubstitutionCipher();
                }
                return _instance;
            }
        }

        public void SetMode(KeywordSubstitutionModes mode)
        {
            this.mode = mode;
        }

        public override string KeyToString((string, KeywordSubstitutionModes) keyAndMode)
        {
            return $"{keyAndMode.Item1} using mode {keyAndMode.Item2}";
        }

        public override (string, KeywordSubstitutionModes) GetKey()
        {
            bool validKey = false;
            string key = "";
            KeywordSubstitutionModes mode;
            do
            {
                MyConsole.WriteLine('c', "Enter the key (a word):");
                key = Console.ReadLine().ToLower();
                if (key.All(char.IsLetter))
                {
                    validKey = true;
                }
                else
                {
                    MyConsole.WriteLine('c', "Please only use letters in the input.");
                }
            } while (!validKey);

            int modeChoice = Utilities.Menu('c', "How should the alphabet be completed?", "Mode 1: Letters are added alphabetically after last letter of keyword e.g. keywordabcfg...", "Mode 2: Letters are addded alphabetically starting with last letter of key word e.g. keywordefghi...");
            if (modeChoice == 0)
            {
                mode = KeywordSubstitutionModes.One;
            }
            else
            {
                mode = KeywordSubstitutionModes.Two;
            }

            return (key, mode);
        }

        public int[] Encrypt(int[] plaintext, string keyword)
        {
            return Encrypt(plaintext, (keyword, mode));
        }

        public override int[] Encrypt(int[] plaintext, (string, KeywordSubstitutionModes) keyAndMode)
        {
            string keyword = keyAndMode.Item1;
            KeywordSubstitutionModes mode = keyAndMode.Item2;
            int[] ciphertext = new int[plaintext.Length];
            int[] keyAlphabet = new int[26];
            keyAlphabet = KS_Alphabet(keyword, mode);

            for (int i = 0; i < plaintext.Length; i++)
            {
                ciphertext[i] = keyAlphabet[plaintext[i]];
            }

            return ciphertext;
        }


        public int[] Decrypt(int[] ciphertext, string keyword)
        {
            return Decrypt(ciphertext, (keyword, mode));
        }

        public override int[] Decrypt(int[] ciphertext, (string, KeywordSubstitutionModes) keyAndMode)
        {
            string keyword = keyAndMode.Item1;
            KeywordSubstitutionModes mode = keyAndMode.Item2;
            int[] plaintext = new int[ciphertext.Length];
            int[] keyAlphabetInverse = new int[26];
            int[] keyAlphabet = new int[26];

            keyAlphabetInverse = KS_Alphabet(keyword, mode);
            for (int i = 0; i < 26; i++)
            {
                keyAlphabet[keyAlphabetInverse[i]] = i;
            }

            for (int i = 0; i < ciphertext.Length; i++)
            {
                plaintext[i] = keyAlphabet[ciphertext[i]];
            }

            return plaintext;
        }

        private int[] KS_Alphabet(string keyword, KeywordSubstitutionModes mode)
        {
            List<int> lettersAvailable = new List<int>();
            int[] keyAlphabet = new int[26];
            int lastLetter, currentLetter;

            for (int i = 0; i < 26; i++)
            {
                lettersAvailable.Add(i);
            }

            int[] keywordNoDuplicates = Utilities.ConvertStringToIntegerArray(keyword).Distinct().ToArray();

            for (int i = 0; i < keywordNoDuplicates.Length; i++)
            {
                keyAlphabet[i] = keywordNoDuplicates[i];
                lettersAvailable.Remove(keywordNoDuplicates[i]);
            }


            if (mode == KeywordSubstitutionModes.One)
            {
                for (int i = keywordNoDuplicates.Length; i < 26; i++)
                {
                    keyAlphabet[i] = lettersAvailable[i - keywordNoDuplicates.Length];
                }
            }

            if (mode == KeywordSubstitutionModes.Two)
            {
                lastLetter = keywordNoDuplicates[keywordNoDuplicates.Length - 1];
                currentLetter = (lastLetter + 1) % 26;
                for (int i = keywordNoDuplicates.Length; i < 26; i++)
                {

                    while (!lettersAvailable.Contains(currentLetter))
                    {
                        currentLetter = (currentLetter + 1) % 26;
                    }
                    keyAlphabet[i] = currentLetter;
                    lettersAvailable.Remove(currentLetter);
                }
            }
            return keyAlphabet;
        }

        public override (int[], string) BreakBruteForce()
        {
            KS_Dictionary breakMethod = new KS_Dictionary();
            SetBreakMethod(breakMethod);
            return Break();
        }
    }

    public class KS_Dictionary : BruteForce<(string, KeywordSubstitutionModes)>
    {
        public KS_Dictionary() : base(KeywordSubstitutionCipher.Instance) { }
        public override SolKey<(string, KeywordSubstitutionModes)> Break()
        {
            List<string> words = Utilities.WordDictionary("words.txt");
            KeywordSubstitutionModes[] modes = { KeywordSubstitutionModes.One, KeywordSubstitutionModes.Two };

            foreach (KeywordSubstitutionModes mode in modes)
            {
                foreach (string word in words)
                {
                    TryKey((word, mode));
                }
            }

            return ReturnSolKey();
        }
    }


}