﻿using System;
namespace Technical_Solution
{
    public class PermutationCipher : CipherWithNullCharacter<int[]>
    {
        private static PermutationCipher _instance = null;

        private PermutationCipher()
        {
        }

        public static PermutationCipher Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new PermutationCipher();
                }
                return _instance;
            }
        }

        public int[] Encrypt(int[] plaintext, string key)
        {
            return Encrypt(plaintext, Program.ConvertWordToPermutation(key));
        }

        public override int[] Encrypt(int[] plaintext, int[] permutation)
        {
            int pLength = permutation.Length;
            int[] paddedPlaintext = PadPlaintext(plaintext, pLength);
            int[] ciphertext = new int[paddedPlaintext.Length];

            for (int p = 0; p < pLength; p++)
            {
                for (int i = 0; i < paddedPlaintext.Length / pLength; i++)
                {
                    ciphertext[i * pLength + permutation[p]] = paddedPlaintext[i * pLength + p];
                }
            }
            return ciphertext;
        }

        public int[] Decrypt(int[] ciphertext, string key)
        {
            return Decrypt(ciphertext, Program.ConvertWordToPermutation(key));
        }

        public override int[] Decrypt(int[] ciphertext, int[] permutation)
        {
            int pLength = permutation.Length;
            int[] plaintext = new int[ciphertext.Length];

            for (int p = 0; p < pLength; p++)
            {
                for (int i = 0; i < ciphertext.Length / pLength; i++)
                {
                    plaintext[i * pLength + p] = ciphertext[i * pLength + permutation[p]];
                }
            }
            return plaintext;
        }
    }

    public class PC_BruteForce : PermAndColTran_BruteForce
    {
        public PC_BruteForce() : base(PermutationCipher.Instance) { }
    }
}
