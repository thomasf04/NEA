﻿using System;
using System.Linq;
namespace Technical_Solution
{
    public class PermutationCipher : PermAndColTransCipher
    {
        private static PermutationCipher _instance = null;

        private PermutationCipher() : base("Permutation cipher", false)
        {
        }

        public static PermutationCipher Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new PermutationCipher();
                }
                return _instance;
            }
        }

        public override int EncryptionIndex(int paddedPlaintextLength, int[] permutation, int p, int i)
        {
            return permutation[p] + i * permutation.Length;
        }

        public override int DecryptionIndex(int ciphertextLength, int[] permutation, int p, int i)
        {
            return permutation[p] + i * permutation.Length;
        }

        public override (int[], string) BreakBruteForce()
        {
            PC_BruteForce breakMethod = new PC_BruteForce();
            SetBreakMethod(breakMethod);
            return Break();
        }

    }

    public class PC_BruteForce : PermAndColTran_BruteForce
    {
        public PC_BruteForce() : base(PermutationCipher.Instance) { }
    }
}
