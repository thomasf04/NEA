﻿using System;
namespace Technical_Solution
{
    public class ColumnarTranspositionCipher : CipherWithNullCharacter<int[]>
    {
        private static ColumnarTranspositionCipher _instance = null;

        private ColumnarTranspositionCipher()
        {
        }

        public static ColumnarTranspositionCipher Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new ColumnarTranspositionCipher();
                }
                return _instance;
            }
        }

        public override int[] Encrypt(int[] plaintext, int[] permutation)
        {
            int pLength = permutation.Length;
            int[] paddedPlaintext = PadPlaintext(plaintext, pLength);
            int[] ciphertext = new int[paddedPlaintext.Length];
            for (int p = 0; p < pLength; p++)
            {
                for (int i = 0; i < paddedPlaintext.Length / pLength; i++)
                {
                    ciphertext[permutation[p] * paddedPlaintext.Length / pLength + i] = paddedPlaintext[i * pLength + p];
                }
            }
            return ciphertext;
        }

        public override int[] Decrypt(int[] ciphertext, int[] permutation)
        {
            int pLength = permutation.Length;
            int[] plaintext = new int[ciphertext.Length];

            for (int p = 0; p < pLength; p++)
            {
                for (int i = 0; i < ciphertext.Length / pLength; i++)
                {
                    plaintext[i * pLength + p] = ciphertext[permutation[p] * ciphertext.Length / pLength + i];
                }
            }
            return plaintext;
        }
    }

    public class CT_BruteForce : PermAndColTran_BruteForce
    {
        public CT_BruteForce() : base(ColumnarTranspositionCipher.Instance) { }
    }

}
