﻿using System;
using System.Linq;
namespace Technical_Solution
{
    public class ColumnarTranspositionCipher : PermAndColTransCipher
    {
        private static ColumnarTranspositionCipher _instance = null;

        private ColumnarTranspositionCipher() : base("Columnar transposition cipher", false)
        {
        }

        public static ColumnarTranspositionCipher Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new ColumnarTranspositionCipher();
                }
                return _instance;
            }
        }

        public override int EncryptionIndex(int paddedPlaintextLength, int[] permutation, int p, int i)
        {
            return permutation[p] * paddedPlaintextLength / permutation.Length + i;
        }

        public override int DecryptionIndex(int ciphertextLength, int[] permutation, int p, int i)
        {
            return permutation[p] * ciphertextLength / permutation.Length + i;
        }

        public override (int[], string) BreakBruteForce()
        {
            CT_BruteForce breakMethod = new CT_BruteForce();
            SetBreakMethod(breakMethod);
            return Break();
        }

    }

    public class CT_BruteForce : PermAndColTran_BruteForce
    {
        public CT_BruteForce() : base(ColumnarTranspositionCipher.Instance) { }
    }

}
