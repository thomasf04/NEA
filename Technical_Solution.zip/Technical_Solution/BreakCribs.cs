﻿using System;
namespace Technical_Solution
{
    public interface HasCribs
    {
        (int[], string) BreakCribs(string crib);
    }
}
