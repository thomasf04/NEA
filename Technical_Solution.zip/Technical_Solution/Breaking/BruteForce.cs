﻿using System;
using System.Collections.Generic;
namespace Technical_Solution
{

    //For brute force methods that follow a similar "try all, return best" approach
    public abstract class BruteForce<T> : BreakMethod<T>
    {
        protected SolKey<T> sk;
        protected int[] solution, bestSolution;
        protected double bestFitness = -10;
        protected T bestShift;


        public BruteForce(Cipher<T> cipher) : base(cipher)
        { }

        public SolKey<T> ReturnSolKey()
        {
            sk.solution = bestSolution;
            sk.key = bestShift;
            return sk;
        }


        public void TryKey(T key)
        {
            solution = cipher.Decrypt(ciphertext, key);
            double fitness = Stats.TetragramFitness(solution);
            if (fitness > bestFitness)
            {
                bestSolution = solution;
                bestFitness = fitness;
                bestShift = key;
            }
        }

    }

}
