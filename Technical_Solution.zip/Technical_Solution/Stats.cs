﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Technical_Solution
{
    public static class Stats
    {
        private static double[] frequencies;

        static Stats()
        {
            frequencies = LogFrequencies();
        }

        public static double IndexOfCoincidence(int[] ciphertext)
        {
            double ioc = 0;
            int count;
            for (int i = 0; i <= 26; i++)
            {
                count = ciphertext.Count(x => x == i);
                ioc += count * (count - 1);
            }
            ioc /= (ciphertext.Length * (ciphertext.Length - 1));
            ioc *= 26;
            return ioc;
        }

        public static int NormaliseIndexOfCoincidence(double fitness)
        {
            if (fitness < 0.9021)
            {
                return 0;
            }
            if (fitness > 1.7342)
            {
                return 100;
            }
            else
            {
                return (int)(120.178 * fitness - 108.412);

            }
        }

        public static double[] LogFrequencies()
        {
            double[] frequencies = new double[26 * 26 * 26 * 26];

            using (BinaryReader br = new BinaryReader(File.Open("LogFrequencies.file", FileMode.OpenOrCreate)))
            {
                for (int i = 0; i < 26 * 26 * 26 * 26; i++)
                {
                    frequencies[i] = br.ReadDouble();
                }
            }

            return frequencies;
        }

        static int TetragramIndex(int[] subarray)
        {
            int i = subarray[3] + 26 * subarray[2] + 676 * subarray[1] + 17576 * subarray[0];
            return i;
        }

        public static double TetragramFitness(int[] text)
        {
            double fitness = 0;
            int[] subarray = new int[4];
            for (int i = 0; i <= text.Length - 4; i++)
            {
                Array.Copy(text, i, subarray, 0, 4);
                fitness += frequencies[TetragramIndex(subarray)];
            }
            return fitness / (text.Length - 3);
        }

        public static int NormaliseTetragramFitness(double fitness)
        {
            if (fitness <= -4.75)
            {
                return (int)(19.048 * fitness + 190.48);
            }
            else
            {
                return 100;
            }
        }

        public static double MonogramFitness(int[] ciphertext)
        {
            double[] englishFreqsArray = { 8.55, 1.60, 3.16, 3.87, 12.10, 2.18, 2.09, 4.96, 7.33, 0.22, 0.81, 4.21, 2.53, 7.17, 7.47, 2.07, 0.10, 6.33, 6.73, 8.94, 2.68, 1.06, 1.83, 0.19, 1.72, 0.11 };
            double englishFreqsArrayMagnitude = 25.510137200728654;
            Vector englishFreqs = new Vector(englishFreqsArray);
            double[] messageFreqsArray = CreateFrequencyArray(ciphertext);
            Vector messageFreqs = new Vector(messageFreqsArray);
            double fitness = Vector.CosineAngle(messageFreqs, englishFreqs, englishFreqsArrayMagnitude);
            return fitness;
        }

        public static double[] CreateFrequencyArray(int[] input)
        {
            double[] frequencies = new double[26];

            for (int i = 0; i < 26; i++)
            {
                frequencies[i] = input.Count(c => c == i);
            }

            return frequencies;
        }

        public static int NormaliseMonogramFitness(double fitness)
        {
            return (int)(100 * fitness);
        }

        public static void CompareMonogramFrequencies(int[] ciphertext)
        {
            double[] englishFreqsArray = { 8.55, 1.60, 3.16, 3.87, 12.10, 2.18, 2.09, 4.96, 7.33, 0.22, 0.81, 4.21, 2.53, 7.17, 7.47, 2.07, 0.10, 6.33, 6.73, 8.94, 2.68, 1.06, 1.83, 0.19, 1.72, 0.11 };
            double[] ciphertextFreqsArray = CreateFrequencyArray(ciphertext);

            for (int i = 0; i < 26; i++)
            {

                PrintMonogramBar(i, englishFreqsArray[i], ciphertextFreqsArray[i]);
            }

        }

        public static void PrintMonogramBar(int j, double englishFreq, double ciphertextFreq)
        {
            int englishDashes = (int)englishFreq * 5;
            int ciphertextDashes = (int)ciphertextFreq * 5;

            char letter = (char)(j + 'a');

            MyConsole.Write('c', letter.ToString());
            for (int i = 0; i < englishDashes; i++)
            {
                MyConsole.Write('b', "-");
            }
            Console.Write("\n ");
            for (int i = 0; i < ciphertextFreq; i++)
            {
                MyConsole.Write('g', "-");
            }

            Console.WriteLine();
        }


    }
}