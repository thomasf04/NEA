﻿using System;
namespace Technical_Solution
{
    //The permutation cipher and columnar transposition cipher use identical brute force methods, differing only by the cipher used to decrypt the message
    //Differs from BruteForce abstract class as terminates if acceptable solution found, 
    public abstract class PermAndColTran_BruteForce2 : BreakMethod<int[]>
    {
        private int maxKeyLength = 9;
        public PermAndColTran_BruteForce2(Cipher<int[]> cipher) : base(cipher) { }

        public void SetMaxKeyLength(int maxKeyLength)
        {
            this.maxKeyLength = maxKeyLength;
        }

        public override SolKey<int[]> Break()
        {
            SolKey<int[]> sk;
            int[][] permutations;
            int[] solution, bestSolution = new int[ciphertext.Length];
            double fitness, bestFitness;
            int[] bestPerm = new int[0];
            int keyLength = 1;
            bool acceptablyHighFitness = false;

            bestFitness = Program.TetragramFitness(ciphertext);

            while (!acceptablyHighFitness && keyLength <= maxKeyLength)
            {
                permutations = Program.HeapsAlgorithm(keyLength);
                foreach (int[] perm in permutations)
                {
                    solution = cipher.Decrypt(ciphertext, perm);
                    fitness = Program.TetragramFitness(solution);

                    if (fitness > bestFitness)
                    {
                        bestSolution = solution;
                        bestPerm = perm;
                        bestFitness = fitness;
                        if (Program.NormaliseTetragramFitness(fitness) == 100)
                        {
                            acceptablyHighFitness = true;
                        }
                    }
                }
                keyLength += 1;
            }

            sk.solution = bestSolution;
            sk.key = bestPerm;
            return sk;
        }
    }

    public abstract class PermAndColTran_BruteForce : BruteForce<int[]>
    {
        public PermAndColTran_BruteForce(Cipher<int[]> cipher) : base(cipher) { }

        public override SolKey<int[]> Break()
        {
            int[][] permutations;
            int maxKeyLength = 9;

            for (int keyLength = 1; keyLength <= maxKeyLength; keyLength++)
            {
                permutations = Program.HeapsAlgorithm(keyLength);
                foreach (int[] perm in permutations)
                {
                    TryKey(perm);
                    if (Program.NormaliseTetragramFitness(bestFitness) == 100)
                    {
                        return ReturnSolKey();
                    }
                }
            }

            return ReturnSolKey();
        }
    }

}
