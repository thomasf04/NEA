﻿using System;
namespace Technical_Solution
{
    public class CribNotFoundException : Exception
    {
        public CribNotFoundException()
        {
        }
    }
}