﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;

namespace Technical_Solution
{
    public static class Utilities
    {
        public static char[] punctuationPositions;

        public static void PrintArray<T>(T[] array)
        {
            Console.Write("[ ");
            foreach (T item in array)
            {
                Console.Write($"{item}, ");
            }
            Console.WriteLine("\b\b ]");
        }

        public static void PrintList<T>(List<T> list)
        {
            Console.Write("[ ");
            foreach (T item in list)
            {
                Console.Write($"{item}, ");
            }
            Console.WriteLine("\b\b ]");
        }

        //Letter is assumed to be lower case, a-0, z-25
        public static int Integer(char letter)
        {
            return (int)letter - (int)'a';
        }

        public static string UppercaseLetter(int number)
        {
            char character = (char)(number + 'A');
            return character.ToString();
        }

        //Message is assumed to be in lower case, a-0, z-25
        public static int[] ConvertStringToIntegerArray(string message)
        {
            int[] messageArray = new int[message.Length];
            for (int i = 0; i < message.Length; i++)
            {
                messageArray[i] = Integer(message[i]);
            }
            return messageArray;
        }

        public static string ConvertIntegerArrayToString(int[] messageArray)
        {
            StringBuilder sb = new StringBuilder();
            foreach (int i in messageArray)
            {
                sb.Append((char)(i + (int)'a'));
            }
            return sb.ToString();
        }



        public static int[] CreateBadMatchTable(int[] crib)
        {
            int[] table = new int[26];
            int cribLength = crib.Length;

            for (int i = 0; i < 26; i++)
            {
                table[i] = cribLength;
            }

            for (int i = 0; i < cribLength - 1; i++)
            {
                table[crib[i]] = cribLength - i - 1;
            }

            return table;
        }


        //Requires crib to be at least 2 characters
        public static List<int> BoyerMooreHorspool(int[] text, int[] crib)
        {
            int cribLength = crib.Length;
            if (cribLength < 2)
            {
                throw new ArgumentOutOfRangeException("crib");
            }

            int[] table = CreateBadMatchTable(crib);
            int i = 0;
            int x;
            List<int> occurences = new List<int>();

            while (i <= text.Length - cribLength)
            {
                x = cribLength - 1;
                while (text[i + x] == crib[x] && x > 0)
                {
                    x -= 1;
                }
                if (x == 0)
                {
                    occurences.Add(i);
                }

                i += table[text[i + x]];
            }

            return occurences;
        }

        public static int factorial(int n)
        {
            int x = 1;
            for (int i = 1; i <= n; i++)
            {
                x *= i;
            }
            return x;
        }

        public static int[][] HeapsAlgorithm(int[] array)
        {
            int n = array.Length;
            int[][] permutations = new int[factorial(n)][];
            permutations[0] = (int[])array.Clone();
            int counter = 1;
            int[] c = new int[n];
            int temp;
            for (int j = 0; j < n; j++)
            {
                c[j] = 0;
            }

            int i = 0;
            while (i < n)
            {
                if (c[i] < i)
                {
                    if (i % 2 == 0)
                    {
                        temp = array[0];
                        array[0] = array[i];
                        array[i] = temp;
                    }
                    else
                    {
                        temp = array[c[i]];
                        array[c[i]] = array[i];
                        array[i] = temp;

                    }
                    permutations[counter] = (int[])array.Clone();
                    counter += 1;
                    c[i]++;
                    i = 0;
                }
                if (c[i] == i)
                {
                    c[i] = 0;
                    i++;
                }
            }
            return permutations;

        }

        public static int[][] HeapsAlgorithm(int length)
        {
            int[] array = new int[length];
            for (int i = 0; i < length; i++)
            {
                array[i] = i;
            }
            return HeapsAlgorithm(array);
        }

        public static List<string> WordDictionary(string filename)
        {
            List<string> words = new List<string>();
            using (StreamReader sr = new StreamReader(filename))
            {
                while (!sr.EndOfStream)
                {
                    words.Add(sr.ReadLine());
                }
            }

            return words;
        }

        public static int mod(int a)
        {
            if (a < 0)
            {
                return a - 26 * (int)(a / 26 - 1);
            }
            return a % 26;
        }

        public static bool Coprime26(int x)
        {
            if (x % 2 == 0 || x % 13 == 0)
            {
                return false;
            }
            return true;
        }

        public static int GreatestCommonDivisor(int m, int n)
        {
            while (n != 0)
            {
                m = m % n;
                (m, n) = (n, m);
            }
            return m;
        }

        public static int Menu(char colourChar, string prompt, params string[] options)
        {
            MyConsole.WriteLine(colourChar, prompt);
            return DoMenu(options);
        }

        public static int Menu(string prompt, params string[] options)
        {
            Console.WriteLine(prompt);
            return DoMenu(options);
        }

        public static int DoMenu(params string[] options)
        {
            int offset = Console.CursorTop - 1;
            foreach (string option in options)
            {
                Console.WriteLine($"  {option}");
            }
            int optionNumber = 1;
            bool optionSelected = false;

            while (!optionSelected)
            {
                Console.CursorTop = offset + optionNumber;
                Console.CursorLeft = 0;
                Console.Write(">");

                ConsoleKeyInfo choice = Console.ReadKey(true);
                Console.CursorTop = offset + optionNumber;
                Console.CursorLeft = 0;
                Console.Write(" ");
                if (choice.Key == ConsoleKey.DownArrow && optionNumber < options.Length)
                {
                    optionNumber++;
                }
                else if (choice.Key == ConsoleKey.UpArrow && optionNumber > 1)
                {
                    optionNumber--;
                }
                else if (choice.Key == ConsoleKey.Enter)
                {
                    Console.CursorTop = offset + options.Length + 1;
                    optionSelected = true;
                }
            }
            Console.Clear();
            return optionNumber - 1;
        }


        public static T[][] GenerateCombinations<T>(T[] array, int l)
        {
            int cLength = (int)Math.Pow(array.Length, l);
            T[][] combinations = new T[cLength][];
            T[][] subCombinations;
            int counter = 0;


            if (l == 1)
            {
                for (int i = 0; i < array.Length; i++)
                {
                    combinations[i] = new T[] { array[i] };
                }
                return combinations;
            }

            subCombinations = GenerateCombinations(array, l - 1);
            foreach (T[] combination in subCombinations)
            {
                foreach (T element in array)
                {
                    combinations[counter] = combination.Concat(new T[] { element }).ToArray();
                    counter++;
                }
            }

            return combinations;
        }

        public static int[] ConvertBaseN(int x, int n, int length)
        {
            int[] array = new int[length];

            for (int i = 0; i < length; i++)
            {
                array[length - i - 1] = x % n;
                x = x / n;
            }

            return array;
        }

        public static int[] ConvertBaseN(int x, int n)
        {
            int length;
            if (x == 0)
            {
                length = 1;
            }
            else
            {
                length = (int)Math.Log(x, n) + 1;

            }
            return ConvertBaseN(x, n, length);
        }

        public static int[,] Convert1DArrayToSquareArray(int[] array, int size)
        {
            if (array.Length != size * size)
            {
                throw new ArgumentException();
            }

            int[,] squareArray = new int[size, size];

            for (int i = 0; i < array.Length; i++)
            {
                squareArray[i / size, i % size] = array[i];
            }

            return squareArray;

        }

        public static string CleanString(string input)
        {
            string output = Regex.Replace(input.ToLower(), @"[^a-z]", "");
            return output;
        }


        public static T[][] SlicePeriodically<T>(T[] array, int period)
        {
            T[][] slices = new T[period][];
            int i, index;

            for (int j = 0; j < period; j++)
            {
                index = 0;
                i = j;
                slices[j] = new T[(array.Length - j - 1) / period + 1];
                while (i < array.Length)
                {
                    slices[j][index] = array[i];
                    i += period;
                    index += 1;
                }
            }
            return slices;
        }

        public static int[] PermutationInverse(int[] permutation)
        {
            int[] inverse = new int[permutation.Length];
            for (int i = 0; i < permutation.Length; i++)
            {
                inverse[permutation[i]] = i;
            }
            return inverse;
        }


        public static int[] ConvertWordToPermutation(string wordString)
        {
            int[] word = ConvertStringToIntegerArray(wordString).Distinct().ToArray();
            Console.WriteLine(ConvertIntegerArrayToString(word));
            int[] wordSorted = (int[])word.Clone();
            Array.Sort(wordSorted);
            int[] permutation = new int[word.Length];

            for (int i = 0; i < permutation.Length; i++)
            {
                permutation[i] = Array.IndexOf(wordSorted, word[i]);
            }

            return permutation;
        }

        public static char[] PositionsOfPunctuation(string input)
        {
            char[] punctuation = new char[input.Length];
            int ascii;
            for (int i = 0; i < input.Length; i++)
            {
                ascii = (int)input[i];
                if ((int)'A' <= ascii && ascii <= (int)'Z')
                {
                    punctuation[i] = 'A';
                }
                else if (ascii < (int)'a' || ascii > (int)'z')
                {
                    punctuation[i] = input[i];
                }
            }
            return punctuation;
        }

        public static string ReinputPunctuation(string text)
        {
            string newText = "";
            int j = 0;
            for (int i = 0; i < punctuationPositions.Length; i++)
            {
                if (punctuationPositions[i] == 'A')
                {
                    newText += text[j].ToString().ToUpper();
                    j++;
                }
                else if (punctuationPositions[i] == (char)0)
                {
                    newText += text[j].ToString();
                    j++;
                }
                else
                {
                    newText += punctuationPositions[i].ToString();
                }
            }
            newText += text.Substring(j, text.Length - j);
            return newText;
        }
    }
}