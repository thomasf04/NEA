﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;
using System.Text.RegularExpressions;
//using System.Windows.Forms;

namespace Technical_Solution
{

    public class Program
    {
        public static double[] frequencies;
        public static Cipher[] ciphers;
        public static string[] cipherNames;
        public static bool walkthrough;

        public static void UpdateWalkthrough()
        {
            int choice = Utilities.Menu('c', "Would you like to activate walkthrough?", "Yes", "No");
            if (choice == 0)
            {
                Walkthrough.Instance.Activate();
            }
            else
            {
                Walkthrough.Instance.TurnOff();
            }
        }


        static int[] MonoDecrypt(int[] ciphertext, int[] keyAlphabet)
        {
            int[] plaintext = new int[ciphertext.Length];
            for (int i = 0; i < ciphertext.Length; i++)
            {
                plaintext[i] = keyAlphabet[ciphertext[i]];
            }
            return plaintext;
        }

        static SolKey<string> MonoalphabeticHillClimbing(int[] ciphertext)
        {
            SolKey<string> sk;
            int[] parentPlaintext, childPlaintext;
            int[] parentKeyAlphabet = new int[26];
            int[] childKeyAlphabet;
            Random rnd = new Random();
            int x, y, temp;
            double parentFitness, childFitness;
            int counter = 0;

            for (int i = 0; i < 26; i++)
            {
                parentKeyAlphabet[i] = i;
            }

            parentPlaintext = MonoDecrypt(ciphertext, parentKeyAlphabet);
            parentFitness = Stats.TetragramFitness(ciphertext);

            while (counter < 10000)
            {
                childKeyAlphabet = (int[])parentKeyAlphabet.Clone();
                x = rnd.Next(26);
                y = rnd.Next(26);
                temp = childKeyAlphabet[x];
                childKeyAlphabet[x] = childKeyAlphabet[y];
                childKeyAlphabet[y] = temp;

                childPlaintext = MonoDecrypt(ciphertext, childKeyAlphabet);
                childFitness = Stats.TetragramFitness(childPlaintext);

                if (childFitness > parentFitness)
                {
                    parentKeyAlphabet = (int[])childKeyAlphabet.Clone();
                    parentPlaintext = (int[])childPlaintext.Clone();
                    parentFitness = childFitness;
                    counter = 0;
                }
                counter += 1;
            }
            sk.solution = parentPlaintext;
            sk.key = Utilities.ConvertIntegerArrayToString(Utilities.PermutationInverse(parentKeyAlphabet));
            return sk;
        }


        static Cipher CipherIdentifier(int[] ciphertext)
        {
            double monogramFitness = Stats.MonogramFitness(ciphertext);
            int normMonogramFitness = Stats.NormaliseMonogramFitness(monogramFitness);
            if (normMonogramFitness >= 95)
            {
                Walkthrough.IdentifierMonogram(ciphertext, monogramFitness, true);

                double tetragramFitness = Stats.TetragramFitness(ciphertext);
                int normTetragramFitness = Stats.NormaliseMonogramFitness(tetragramFitness);
                if (normTetragramFitness >= 95)
                {
                    //English
                    Walkthrough.IdentifierEnglish(tetragramFitness, true);
                    return null;
                }
                else
                {
                    Walkthrough.IdentifierEnglish(tetragramFitness, false);
                    return TranspositionCipherIdentider(ciphertext);
                }
            }
            else
            {
                Walkthrough.IdentifierMonogram(ciphertext, monogramFitness, false);
                double indexOfCoincidence = Stats.IndexOfCoincidence(ciphertext);
                if (Stats.NormaliseIndexOfCoincidence(indexOfCoincidence) >= 90)
                {
                    Walkthrough.IdentifierIoC(indexOfCoincidence, true);
                    (double, bool) bestWithAffine = BestFitnessWithAffine();
                    double bestWithAffineFitness = bestWithAffine.Item1;
                    bool equivalentToCaesar = bestWithAffine.Item2;
                    if (Stats.NormaliseTetragramFitness(bestWithAffineFitness) >= 95)
                    {
                        Walkthrough.IdentifierAffine(bestWithAffineFitness, true);
                        Walkthrough.IdentifierCaesar(equivalentToCaesar);
                        //If multilplier is 1 i.e. cipher used is Caesar
                        if (equivalentToCaesar)
                        {
                            return CaesarCipher.Instance;
                        }
                        else
                        {
                            return AffineCipher.Instance;
                        }
                    }
                    else
                    {
                        Walkthrough.IdentifierAffine(bestWithAffineFitness, false);
                        MyConsole.WriteLine('c', "This may take a few seconds...");
                        double bestWithKeywordSubstitution = BestWithKeywordSubstitution();
                        if (Stats.NormaliseTetragramFitness(bestWithKeywordSubstitution) >= 95)
                        {
                            Walkthrough.IdentifierKeyword(bestWithKeywordSubstitution, true);
                            return KeywordSubstitutionCipher.Instance;
                        }
                        else
                        {
                            Walkthrough.IdentifierKeyword(bestWithKeywordSubstitution, false);
                            return null;
                        }
                    }
                }
                else
                {
                    Walkthrough.IdentifierIoC(indexOfCoincidence, false);
                    return PolyalphabeticCipherIdentifer();

                }
            }


        }

        static (double, bool) BestFitnessWithAffine()
        {
            AffineCipher cipher = AffineCipher.Instance;
            cipher.SetBreakMethod(new AC_BruteForce());
            SolKey<(int, int)> sk = cipher.Break_sk();
            int[] plaintext = sk.solution;
            double fitness = Stats.TetragramFitness(plaintext);
            int a = sk.key.Item1;
            bool equivalentToCaesar = (a == 1);
            return (fitness, equivalentToCaesar);

        }



        static Cipher PolyalphabeticCipherIdentifer()
        {
            Walkthrough.IdentifierPolyalphabetic();
            MyConsole.WriteLine('c', "This might take a couple seconds...");
            VigenereCipher cipher = VigenereCipher.Instance;
            cipher.SetBreakMethod(new VC_BruteForce());
            SolKey<string> sk;
            try
            {
                sk = cipher.Break_sk();
            }
            catch (NotEncryptedWithVigenereException)
            {
                Walkthrough.IdentifierHill();
                return HillCipher.Instance; ;
            }
            Walkthrough.IdentifierVigenere();
            int[] plaintext = sk.solution;
            double fitness = Stats.TetragramFitness(plaintext);
            if (Stats.NormaliseTetragramFitness(fitness) >= 95)
            {
                return VigenereCipher.Instance;
            }
            else
            {
                return HillCipher.Instance;
            }
        }

        static Cipher TranspositionCipherIdentider(int[] ciphertext)
        {
            Walkthrough.IdentifierTransposition();
            Cipher[] TranspositionCiphers = new Cipher[] { ScytaleCipher.Instance, RailfenceCipher.Instance, PermutationCipher.Instance, ColumnarTranspositionCipher.Instance };

            ScytaleCipher.Instance.SetBreakMethod(new SC_BruteForce());
            RailfenceCipher.Instance.SetBreakMethod(new RF_BruteForce());
            PermutationCipher.Instance.SetBreakMethod(new PC_BruteForce());
            ColumnarTranspositionCipher.Instance.SetBreakMethod(new CT_BruteForce());

            double fitness;
            double bestFitness = -10;
            Cipher bestCipher = null;
            foreach (Cipher cipher in TranspositionCiphers)
            {
                MyConsole.WriteLine('c', $"Trying {cipher.Name}...");
                fitness = Stats.TetragramFitness(cipher.Break().Item1);
                if (fitness > bestFitness)
                {

                    if (Stats.NormaliseTetragramFitness(fitness) >= 95)

                    {
                        return cipher;

                    }
                    bestFitness = fitness;
                    bestCipher = cipher;
                }
            }
            return bestCipher;
        }

        static double BestWithKeywordSubstitution()
        {
            KeywordSubstitutionCipher cipher = KeywordSubstitutionCipher.Instance;
            cipher.SetBreakMethod(new KS_Dictionary());
            (int[], string) sk = cipher.Break();
            int[] plaintext = sk.Item1;
            double fitness = Stats.TetragramFitness(plaintext);
            return fitness;
        }


        static int[] GetText(int entryChoice, string textType)
        {
            string text = "";
            bool valid = false;
            if (entryChoice == 0)
            {
                do
                {
                    MyConsole.WriteLine('c', $"Enter the {textType} below (press enter when you're done): ");
                    text = Console.ReadLine();

                    if (text.Length >= 2000)
                    {
                        MyConsole.WriteLine('r', $"The length of the {textType} must be below 2,000 letters");
                        MyConsole.WriteLine('r', $"Current length is {text.Length}");
                        MyConsole.WriteLine('r', "Please make the input shorter");
                    }
                    else if (text.Length == 0)
                    {
                        MyConsole.WriteLine('r', $"No text was entered");
                        MyConsole.WriteLine('r', $"Please type the text into the box below");

                    }
                    else { valid = true; }
                    
                } while  (!valid);

            }
            if (entryChoice == 1)
            {
                do
                {
                    MyConsole.WriteLine('c', "Enter the filename (include extension):");
                    string filename = Console.ReadLine();

                    try
                    {
                        text = File.ReadAllText(filename);
                        if (text.Length >= 2000)
                        {
                            MyConsole.WriteLine('r', $"{textType.ToUpper()} length must be below 2,000 letters");
                            MyConsole.WriteLine('r', $"Current length is {text.Length}");
                            MyConsole.WriteLine('r', "Please make the input shorter");
                        }
                        else
                        {
                            valid = true;
                        }
                    }
                    catch (ArgumentException)
                    {
                        MyConsole.WriteLine('r', $"No file with that name was found");
                        MyConsole.WriteLine('r', $"Please enter a different file name");
                    }

                } while (!valid);

                MyConsole.WriteLine('c', "Text successfully loaded:");
                Console.WriteLine(text);
            }
            Utilities.punctuationPositions = Utilities.PositionsOfPunctuation(text);
            return Utilities.ConvertStringToIntegerArray(Utilities.CleanString(text));
        }

        static int[] Text(string textType)
        {
            int[] text = new int[0];
            bool validText = false;
            while (!validText)
            {
                int entryChoice = Utilities.Menu('c', $"Enter {textType} into console or load from file?", "Enter into console", "Load from file");
                try
                {
                    text = GetText(entryChoice, textType);
                    validText = true;
                }
                catch (FileNotFoundException)
                {
                    MyConsole.WriteLine('r', "No file with that name was found. Please make sure the file is in the bin/debug folder of this project");
                }
            }
            return text;
        }



        static string Encipher()
        {
            int[] plaintext = Text("plaintext");
            int[] ciphertext;
            string key;
            Cipher cipher = SelectCipher("Which cipher would you like to encrpt the mssage with?");
            if (cipher == null)
            {
                return null;
            }
            UpdateWalkthrough();
            (ciphertext, key) = cipher.EncryptReturnKey(plaintext);

            MyConsole.WriteLine('c', $"The key alphabet used is: ");
            Console.WriteLine(key);

            string ciphertextString = Utilities.ConvertIntegerArrayToString(ciphertext);


            Console.WriteLine(Utilities.ReinputPunctuation(ciphertextString));
            return ciphertextString;
        }

        static string Decipher()
        {
            int[] ciphertext = Text("ciphertext");

            try
            {
                if (ciphertext.Length < 250)
                {
                    return DecipherSimple(ciphertext);
                }
                else
                {
                    return DecipherComplex(ciphertext);
                }
            }
            catch (NotEncryptedWithVigenereException)
            {
                MyConsole.WriteLine('r', "It doesn't look like this message was encrypted with a Vigenere cipher, so it can't be decrypted");
                MyConsole.WriteLine('c', "Press any key to continue)");
                Console.ReadKey();
                Console.WriteLine();
                return null;
            }

        }


        //Breaking not available
        static string DecipherSimple(int[] ciphertext)
        {
            int[] plaintext;
            MyConsole.WriteLine('r', "Because the ciphertext is shorter than 250 characters, breaking is not available.");
            Cipher cipher = SelectCipher("Which cipher would you like to decrypt the message with?");
            if (cipher == null)
            {
                return null;
            }
            UpdateWalkthrough();
            plaintext = cipher.Decrypt(ciphertext);
            string plaintextString = Utilities.ConvertIntegerArrayToString(plaintext);
            MyConsole.WriteLine('c', "The plaintext is:");
            Console.WriteLine(Utilities.ReinputPunctuation(plaintextString));

            return plaintextString;
        }



        //Breaking available
        static string DecipherComplex(int[] ciphertext)
        {
            BreakMethod.SetCiphertext(ciphertext);
            int[] plaintext;
            bool broken = false;
            string plaintextString;
            int cipherKnown = Utilities.Menu('c', "Do you know which cipher has been used to encrypt this?", "Yes", "No");

            Cipher cipher;
            if (cipherKnown == 0)
            {
                cipher = SelectCipher("Which cipher would you like to decrypt the message with?");
                if (cipher == null)
                {
                    return null;
                }
            }
            else
            {
                UpdateWalkthrough();
                cipher = CipherIdentifier(ciphertext);
                broken = true;
            }

            //English or monoalphabetic
            if (cipher == null)
            {
                if (Stats.NormaliseTetragramFitness(Stats.TetragramFitness(ciphertext)) >= 95)
                {
                    MyConsole.WriteLine('c', "This message is likely not encrypted.");
                    MyConsole.WriteLine('c', "Press any key return to the main menu");
                    return null;
                }
                else
                {
                    MyConsole.WriteLine('c', "This message has probably been encrypted with a monoalphabetic substition cipher.");
                    MyConsole.WriteLine('c', "Unfortunately, it has been encrypted with a cipher than we don't know about yet.");
                    MyConsole.WriteLine('c', "Press any key to brute force attack the ciphertext");
                    Console.ReadKey();
                    plaintextString = BreakMono(ciphertext);
                    return plaintextString;
                }

            }
            if (cipher != null)
            {
                Console.Clear();
                if (broken)
                {
                    MyConsole.WriteLine('c', $"The cipher used was {cipher.Name}.");
                }
                int keyKnown = Utilities.Menu('c', "Do you know the key that has been used to encrypt this message?", "Yes", "No");
                if (keyKnown == 0)
                {
                    UpdateWalkthrough();
                    plaintext = cipher.Decrypt(ciphertext);
                    plaintextString = Utilities.ConvertIntegerArrayToString(plaintext);
                    MyConsole.WriteLine('c', "The plaintext is:");
                    Console.WriteLine(Utilities.ReinputPunctuation(plaintextString));

                    return plaintextString;
                }
                else
                {
                    UpdateWalkthrough();
                    plaintextString = Break(cipher, ciphertext);
                    return plaintextString;
                }

            }
            return "";
        }

        static string BreakMono(int[] ciphertext)
        {
            MyConsole.WriteLine('c', "Trying all possible key alphabets...");
            SolKey<string> sk = MonoalphabeticHillClimbing(ciphertext);
            string plaintextString = Utilities.ConvertIntegerArrayToString(sk.solution);
            MyConsole.Write('c', $"The key alphabet used is: ");
            Console.WriteLine(sk.key);
            MyConsole.WriteLine('c', "Plaintext:");
            Console.WriteLine(Utilities.ReinputPunctuation(plaintextString));

            return plaintextString;
        }

        static string Break(Cipher cipherIn, int[] ciphertext)
        {
            string plaintextString = "";
            BreakMethod.SetCiphertext(ciphertext);
            bool broken = false;
            if (cipherIn.HasCribBreakMethods == true)
            {
                int cribChoice = 2;
                do
                {
                    cribChoice = Utilities.Menu('c', "Would you like to use cribs to break this cipher?", "Yes", "No", "What is a crib?");

                    if (cribChoice == 0)
                    {
                        string crib = GetCrib();
                        if (crib != null)
                        {
                            try
                            {
                                plaintextString = BreakCribs(cipherIn, crib);
                                broken = true;
                            }
                            catch (CribNotFoundException)
                            {
                                MyConsole.WriteLine('c', $"Bad luck. Doesn't look like '{crib}' appears anywhere in the plaintext.");
                            }
                        }
                    }
                    if (cribChoice == 2)
                    {
                        MyConsole.WriteLine('y', "A crib is a piece of text that you have strong reason to believe is part of the plaintext");
                    }
                } while (cribChoice == 2);
            }

            if (!broken)
            {
                MyConsole.WriteLine('c', "The ciphertext will be broken using bruteforce");
                plaintextString = BreakBruteForce(cipherIn);

            }

            return plaintextString;
        }


        static string BreakCribs(Cipher cipherIn, string crib)
        {
            HasCribs cipher = (HasCribs)cipherIn;
            (int[], string) sk = cipher.BreakCribs(crib);
            int[] solution = sk.Item1;
            string plaintextString = Utilities.ConvertIntegerArrayToString(solution);
            MyConsole.WriteLine('c', $"Key used:");
            Console.WriteLine(sk.Item2);
            MyConsole.WriteLine('c', "Plaintext:");
            Console.WriteLine(Utilities.ReinputPunctuation(plaintextString));
            Console.ReadKey();

            return plaintextString;
        }

        static string GetCrib()
        {
            string crib;
            int cribChoice = Utilities.Menu('c', "Do you know any cribs?", "Yes", "No");
            switch (cribChoice)
            {
                case 0:
                    MyConsole.WriteLine('c', "Enter the crib");
                    crib = Utilities.CleanString(Console.ReadLine());
                    if (crib.Length < 4)
                    {
                        MyConsole.WriteLine('c', "The crib must be at least four letters long");
                        MyConsole.WriteLine('c', "Press any key to continue");
                        Console.ReadKey();
                        return GetCrib();
                    }
                    else
                    {
                        return crib;
                    }
                default:
                    return null;
            }
        }

        static string BreakBruteForce(Cipher cipher)
        {
            (int[], string) sk = cipher.BreakBruteForce();
            int[] solution = sk.Item1;
            string plaintextString = Utilities.ConvertIntegerArrayToString(solution);
            MyConsole.Write('c', "Key used:");
            Console.WriteLine(sk.Item2);
            MyConsole.WriteLine('c', "Plaintext:");
            Console.WriteLine(Utilities.ReinputPunctuation(plaintextString));
            Console.ReadKey();

            return plaintextString;
        }


        static Cipher SelectCipher(string prompt)
        {
            int cipherChoice;
            int choice = 1;
            do
            {
                cipherChoice = Utilities.Menu('c', prompt, cipherNames.Append("None of the above").ToArray());
                if (cipherChoice == ciphers.Length)
                {
                    MyConsole.WriteLine('r', "Unfortunately, you can only encrypt and decrypt messages using the ciphers displyed on the previous menu");
                    choice = Utilities.Menu('c', "", "Choose a different cipher", "Return to main menu");

                    if (choice == 1)
                    {
                        return null;
                    }
                }

            } while (choice == 0);

            Cipher cipher = ciphers[cipherChoice];
            return cipher;
        }


        static void SaveToFile(string text)
        {
            MyConsole.WriteLine('c', "Enter the filename (include extension):");
            string filename = Console.ReadLine();
            using (StreamWriter writer = new StreamWriter(filename))
            {
                writer.WriteLine(text);
            }
            MyConsole.WriteLine('c', "File successfully written to");
            MyConsole.WriteLine('c', "Press any key to continue");
            Console.ReadKey();
        }

        static void SaveToClipboard(string text)
        {
            //Clipboard.SetText(text);
            MyConsole.WriteLine('c', "Successfully written to clipboard");
            MyConsole.WriteLine('c', "Press any key to continue");
            Console.ReadKey();
        }

        static void InitiliaseCiphers()
        {
            AffineCipher AC = AffineCipher.Instance;
            CaesarCipher CC = CaesarCipher.Instance;
            KeywordSubstitutionCipher KS = KeywordSubstitutionCipher.Instance;
            VigenereCipher VC = VigenereCipher.Instance;
            HillCipher HC = HillCipher.Instance;
            ScytaleCipher SC = ScytaleCipher.Instance;
            RailfenceCipher RF = RailfenceCipher.Instance;
            PermutationCipher PC = PermutationCipher.Instance;
            ColumnarTranspositionCipher CT = ColumnarTranspositionCipher.Instance;

            ciphers = new Cipher[] { AC, CC, KS, VC, HC, SC, RF, PC, CT }.OrderBy(c => c.Id).ToArray();

            cipherNames = new string[ciphers.Length];
            for (int i = 0; i < ciphers.Length; i++)
            {
                cipherNames[i] = ciphers[i].Name;
            }
        }


        [STAThread]
        static void Main(string[] args)
        {
            InitiliaseCiphers();

            int choice, outputChoice;
            string text;
            while (true)
            {
                Console.Clear();
                MyConsole.WriteLine('r', "Welcome to CrytpanalAssistor!");
                choice = Utilities.Menu('c', "Would you like to encipher or decipher a message?", "Encipher", "Decipher");
                if (choice == 0)
                {
                    text = Encipher();
                }
                else
                {
                    text = Decipher();
                }

                if (text != null)
                {
                    text = Utilities.ReinputPunctuation(text);
                    outputChoice = Utilities.Menu("", "Copy output to clipboard", "Save output to file", "Return to main menu");
                    if (outputChoice == 0)
                    {
                        SaveToClipboard(text);
                    }
                    if (outputChoice == 1)
                    {
                        SaveToFile(text);
                    }
                }
            }
        }
    }
}