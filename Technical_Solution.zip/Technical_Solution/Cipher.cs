﻿using System;
namespace Technical_Solution
{
    public abstract class Cipher<T>
    { 
        protected BreakMethod<T> breakMethod;
        protected SolKey<T> sk;

        public void SetBreakMethod(BreakMethod<T> breakMethod)
        {
            this.breakMethod = breakMethod;
        }

        public SolKey<T> Break()
        {
            return breakMethod.Break();
        }

        public abstract int[] Encrypt(int[] plaintext, T key);
        
        public abstract int[] Decrypt(int[] ciphertext, T key);

    }

    public abstract class CipherWithNullCharacter<T> : Cipher<T>
    {
        protected char nullCharacter = 'x';
        public void SetNullCharacter(char nullCharacter)
        {
            this.nullCharacter = nullCharacter;
        }

        //Increases plaintext length until it is a multiple of 'x'
        protected int[] PadPlaintext(int[] plaintext, int x)
        {
            int lengthOfPaddedPlaintext = LengthOfPaddedPlaintext(plaintext, x);
            int[] paddedPlaintext = new int[lengthOfPaddedPlaintext];
            plaintext.CopyTo(paddedPlaintext, 0);

            for (int i = plaintext.Length; i < lengthOfPaddedPlaintext; i++)
            {
                paddedPlaintext[i] = Program.Integer(nullCharacter);
            }

            return paddedPlaintext;
        }

        protected int LengthOfPaddedPlaintext(int[] plaintext, int x)
        {
            int lengthOfPaddedPlaintext = plaintext.Length;
            if (plaintext.Length % x != 0)
            {
                lengthOfPaddedPlaintext += x - (plaintext.Length % x);
            }
            return lengthOfPaddedPlaintext;
        }

    }

    //SolKey is a structure with a solution and a key
    public struct SolKey<T>
    {
        public int[] solution;
        public T key;
    }


}