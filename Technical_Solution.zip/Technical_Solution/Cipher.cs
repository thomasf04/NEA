﻿using System;
namespace Technical_Solution
{
    public abstract class Cipher 
    {
        private string name;
        protected int cipherId;
        protected static int nextId = 0;
        protected bool hasCribBreakMethods;
        public Cipher(string name, bool hasCribBreakMethods)
        {
            this.name = name;
            this.hasCribBreakMethods = hasCribBreakMethods;
            cipherId = nextId;
            nextId++;
        }

        public string Name
        {
            get { return name; }
        }

        public int Id
        {
            get { return cipherId; }
        }

        public bool HasCribBreakMethods
        {
            get { return hasCribBreakMethods; }
        }

        //These methods do not specify the key type
        //Hence break returns key as string
        public abstract int[] Encrypt(int[] plaintext);
        public abstract (int[],string) EncryptReturnKey(int[] plaintext);
        public abstract int[] Decrypt(int[] ciphertext);
        public abstract (int[], string) Break();
        public abstract (int[], string) BreakBruteForce();

    }

    public abstract class Cipher<T> : Cipher
    {
        protected BreakMethod<T> breakMethod;
        protected SolKey<T> sk;

        public Cipher(string name, bool hasCribBreakMethods) : base(name, hasCribBreakMethods) { }

        public void SetBreakMethod(BreakMethod<T> breakMethod)
        {
            this.breakMethod = breakMethod;
        }

        public SolKey<T> Break_sk()
        {
            return breakMethod.Break();
        }

        public override (int[], string) Break()
        {
            SolKey<T> sk = Break_sk();
            string keyString = KeyToString(sk.key);
            return (sk.solution, keyString);
        }

        public abstract string KeyToString(T key);

        public abstract T GetKey();

        public override int[] Encrypt(int[] plaintext)
        {
            return Encrypt(plaintext, GetKey());
        }

        public override (int[],string) EncryptReturnKey(int[] plaintext)
        {
            T key = GetKey();
            return (Encrypt(plaintext, key), KeyToString(key));
        }

        public override int[] Decrypt(int[] ciphertext)
        {
            return Decrypt(ciphertext, GetKey());
        }

        public abstract int[] Encrypt(int[] plaintext, T key);

        public abstract int[] Decrypt(int[] ciphertext, T key);

    }

    public abstract class CipherWithNullCharacter<T> : Cipher<T>
    {
        protected char nullCharacter = 'x';

        public CipherWithNullCharacter(string name, bool hasCribBreakMethods) : base(name, hasCribBreakMethods) { }

        public void SetNullCharacter(char nullCharacter)
        {
            this.nullCharacter = nullCharacter;
        }

        //Increases plaintext length until it is a multiple of 'x'
        protected int[] PadPlaintext(int[] plaintext, int x)
        {
            int lengthOfPaddedPlaintext = LengthOfPaddedPlaintext(plaintext, x);
            int[] paddedPlaintext = new int[lengthOfPaddedPlaintext];
            plaintext.CopyTo(paddedPlaintext, 0);

            for (int i = plaintext.Length; i < lengthOfPaddedPlaintext; i++)
            {
                paddedPlaintext[i] = Utilities.Integer(nullCharacter);
            }

            return paddedPlaintext;
        }

        protected int LengthOfPaddedPlaintext(int[] plaintext, int x)
        {
            int lengthOfPaddedPlaintext = plaintext.Length;
            if (plaintext.Length % x != 0)
            {
                lengthOfPaddedPlaintext += x - (plaintext.Length % x);
            }
            return lengthOfPaddedPlaintext;
        }

    }

    //SolKey is a structure with a solution and a key
    public struct SolKey<T>
    {
        public int[] solution;
        public T key;
    }


}