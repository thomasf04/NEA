﻿using System;
namespace Technical_Solution
{
    public class ScytaleCipher : CipherWithNullCharacter<int>
    {
        private static ScytaleCipher _instance = null;

        private ScytaleCipher() : base("Scytale cipher")
        {
        }

        public static ScytaleCipher Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new ScytaleCipher();
                }
                return _instance;
            }
        }

        public override int GetKey()
        {
            bool validKey = false;
            int key = 0;
            do
            {
                Console.WriteLine("Enter the key (a number):");
                validKey = int.TryParse(Console.ReadLine(), out key);
                if (!validKey)
                {
                    Console.WriteLine("Please enter a number.");
                }

            } while (!validKey);
            return key;
        }

        //Key is taken to be number of columns of matrix
        public override int[] Encrypt(int[] plaintext, int key)
        {
            int[] ciphertext = new int[LengthOfPaddedPlaintext(plaintext, key)];
            int counter = 0;

            //Integer division in outer for loop
            for (int i = 0; i < ciphertext.Length / key; i++)
            {
                for (int j = 0; j < key; j++)
                {
                    if (counter < plaintext.Length)
                    {
                        ciphertext[ciphertext.Length / key * j + i] = plaintext[counter];

                    }
                    else
                    {
                        ciphertext[ciphertext.Length / key * j + i] = Program.Integer(nullCharacter);
                    }
                    counter += 1;
                }
            }

            return ciphertext;
        }

        public override int[] Decrypt(int[] ciphertext, int key)
        {
            int[] plaintext = Encrypt(ciphertext, ciphertext.Length / key);
            return plaintext;

        }

    }

    public class SC_BruteForce : BruteForce<int>
    {
        public SC_BruteForce() : base(ScytaleCipher.Instance) { }

        public override SolKey<int> Break()
        {
            int maxKey = ciphertext.Length / 2;
            for (int i = 1; i < maxKey; i++)
            {
                TryKey(i);
            }

            return ReturnSolKey();
        }
    }
}
