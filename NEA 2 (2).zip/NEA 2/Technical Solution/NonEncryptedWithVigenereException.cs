﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Technical_Solution
{
    public class NotEncryptedWithVigenereException : Exception
    {
        public NotEncryptedWithVigenereException() : base("The message was not encrypted with a Vigenere cipher")
        {
        }
    }
}
